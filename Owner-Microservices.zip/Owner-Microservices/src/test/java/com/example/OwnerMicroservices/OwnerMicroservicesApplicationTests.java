package com.example.OwnerMicroservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwnerMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
